<?php $__env->startSection('content'); ?>
    <h2>Просмотр роли</h2>

        <div class="form-group">
            <label for="name">Название</label>
            <input type="text" required name="name" value="<?php echo e($role->name); ?>" class="form-control" placeholder="Введите название роли">
        </div>
        <div class="form-group">
            <label for="name">Права доступа</label>
            <div style="max-height: 105px;" class="d-flex flex-wrap flex-column">
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="form-check">
                        <label class="form-check-label badge <?php if($role->hasPermissionTo($permission->name)): ?> bg-primary <?php endif; ?> <?php if(!$role->hasPermissionTo($permission->name)): ?> bg-secondary <?php endif; ?>  me-1" for="permissions_<?php echo e($permission->id); ?>" >
                            <?php echo e($permission->name); ?>

                        </label><br>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\Hakaton\resources\views/roles/show.blade.php ENDPATH**/ ?>