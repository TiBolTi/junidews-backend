    <h2>Список клиентов</h2>


        <table class="table table-bordered">
            <thead>
            <tr>
                <th style="text-align: center" scope="col">#</th>
                <th scope="col">Имя клиента</th>
                <th scope="col">Телефон</th>
                <th scope="col">Почта</th>
                <th scope="col" style="text-align: end">Buttons</th>
            </tr>
            </thead>
            <tbody style="vertical-align: middle;">
            <tr>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <td><?php echo e($role->name); ?></td>

                    <td align="end">









                    </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>
<?php if(auth()->user()->can('show roles')): ?>
    <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-success btn " tabindex="-1" role="button">Добавить клиента</a>
<?php endif; ?>


    <?php $__env->startSection('delete'); ?>
        <script>
            var deleteModal = document.getElementById('deleteModal');
            deleteModal.addEventListener('show.bs.modal', function(event) {
                var button = event.relatedTarget;
                var table = button.getAttribute('data-table');
                var id = button.getAttribute('data-id');
                var form = deleteModal.querySelector('form');
                var actionUrl = "<?php echo e(url('/')); ?>/" + table + "/" + id;
                form.setAttribute('action', actionUrl);
            });
        </script>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\Hakaton\resources\views/roles/index.blade.php ENDPATH**/ ?>