<?php $__env->startSection('content'); ?>

        <table  class="table table-bordered mt-5">
            <h2>Список стран</h2>
            <thead>
            <tr>
                <th style="text-align: center; width: 4%;" scope="col">#</th>
                <th scope="col">Название стран</th>
                <th scope="col">Коды стран</th>

            </tr>
            </thead>
            <tbody style="vertical-align: middle;">
            <tr>
                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="text-align: center"><?php echo e($country->id); ?></td>
                    <td>
                        <?php echo e($country->name); ?>

                    </td>

                    <td>
                        <?php echo e($country->iso2); ?>

                    </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

<?php if(auth()->user()->can('add perms')): ?>
    <a href="<?php echo e(route('perms.create')); ?>" class="btn btn-success btn " tabindex="-1" role="button">Добавить разрешение</a>
<?php endif; ?>


    <?php $__env->startSection('delete'); ?>
        <script>
            var deleteModal = document.getElementById('deleteModal');
            deleteModal.addEventListener('show.bs.modal', function(event) {
                var button = event.relatedTarget;
                var table = button.getAttribute('data-table');
                var id = button.getAttribute('data-id');
                var form = deleteModal.querySelector('form');
                var actionUrl = "<?php echo e(url('/')); ?>/" + table + "/delete/" + id;
                form.setAttribute('action', actionUrl);
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\Hakaton\resources\views/countries/index.blade.php ENDPATH**/ ?>