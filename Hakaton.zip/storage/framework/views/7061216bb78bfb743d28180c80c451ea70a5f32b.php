<?php $__env->startSection('content'); ?>
    <h2>Добавить роль</h2>
    <form class="mb-5" action="<?php echo e(route('roles.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="name">Название</label>
            <input type="text" required name="name" class="form-control" placeholder="Введите название роли">
        </div>
        <div class="form-group">
            <label for="name">Права доступа</label>
<div style="max-height: 105px;" class="d-flex flex-wrap flex-column">
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" name="permissions[]" value="<?php echo e($permission->id); ?>" id="permissions_<?php echo e($permission->id); ?>">
                <label class="form-check-label badge bg-secondary me-1" for="permissions_<?php echo e($permission->id); ?>" >
                    <?php echo e($permission->name); ?>

                </label><br>
            </input>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
        </div>

        <button type="submit" class="btn mt-2 btn-primary">Добавить роль</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\Hakaton\resources\views/roles/create.blade.php ENDPATH**/ ?>