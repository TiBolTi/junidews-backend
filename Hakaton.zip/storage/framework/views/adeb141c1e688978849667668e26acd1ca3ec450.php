<?php $__env->startSection('content'); ?>
<div class="container ">
    <div class="row justify-content-center">
        <div class="col-md-10 mt-5">

            <h2>PHR-Converter</h2>
            <?php if(Auth::user()): ?>
            <p>Имя пользователя: <?php echo e(Auth::user()->name); ?></p>
            <p>Роль: <?php echo e(Auth::user()->getRoleNames()->first()); ?></p>
            <?php endif; ?>

            <div class="mt-5">
                <form action="<?php echo e(route('decode.decoder')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="exampleFormControlInput1">Введите запрос</label>


                        <div class="input-group mb-3">
                            <input type="text" class="form-control" name="code" id="exampleFormControlInput1" placeholder="TS1275 J 15OCT 4 LGWYVR HK1 1910 1200+1 332 E 0  ">
                            <div class="input-group-append">
                                <button type="submit" class="btn btn-outline-secondary" type="button">Send</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <?php if($decoding != null): ?>

                <div class="card">
                    <div class="card-body">
                        <div class="d-flex flex-row justify-content-between align-items-center">
                            <div class="col text-start">
                                <span><?php echo e($airline = $decoding['departure_airport']); ?></span><br>
                                <span class="fs-3 fw-bold"><?php echo e($airline = $decoding['departure_time']); ?></span>
                                <span>(<?php echo e($airline = $decoding['departure_date']); ?>)</span>
                            </div>
                            <div class="col text-center">
                                <span><?php echo e($airline = $decoding['airline']); ?></span>
                            </div>
                            <div class="col text-end" >
                                <span><?php echo e($airline = $decoding['arrival_airport']); ?></span><br>
                                <span>(<?php echo e($airline = $decoding['arrival_date']); ?>)</span>
                                <span class="fs-3 fw-bold"><?php echo e($airline = $decoding['arrival_time']); ?></span>


                            </div>
                        </div>
                        <a href="#" class="btn btn-primary card-text read-more mt-3">Подробнее</a>
                    </div>
                    <div class="card-footer bg-transparent detail-text d-none">
                        <p class="fs-5 fw-bold"><?php echo e($airline = $decoding['departure_airport']); ?> --- <?php echo e($airline = $decoding['arrival_airport']); ?>

                        </p>
                        <p><span class="fw-bold"> Авиакомпания:</span> <?php echo e($airline = $decoding['airline']); ?></p>


                        <div class="d-flex justify-content-between">
                            <div class="d-flex flex-column justify-content-center">
                            <span class="fs-5 fw-bold"><?php echo e($airline = $decoding['departure_time']); ?></span>
                            <sapn><?php echo e($airline = $decoding['departure_date']); ?> - <?php echo e($airline = $decoding['week_day']); ?></sapn>
                            </div>

                            <div class="d-flex text-end flex-column">
                            <p><?php echo e($airline = $decoding['departure_airport']); ?> <span class="fw-bold"> - Аэропорт</span></p>
                                <div class="d-flex text-end flex-column">
                            <span><?php echo e($airline = $decoding['departure_country']); ?> <span class="fw-bold"> - Страна</span></span>
                            <?php if($airline = $decoding['departure_state'] != null): ?><span><?php echo e($airline = $decoding['departure_state']); ?> <span class="fw-bold"> - Штат</span><?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <hr>

                        <div class="d-flex justify-content-between">
                            <div class="d-flex flex-column justify-content-center">
                        <span class="fs-5 fw-bold"><?php echo e($airline = $decoding['arrival_time']); ?></span>
                        <span><?php echo e($airline = $decoding['arrival_date']); ?> - <?php echo e($airline = $decoding['week_day']); ?></span>
                            </div>

                            <div class="d-flex text-end flex-column">
                        <p><?php echo e($airline = $decoding['arrival_airport']); ?> <span class="fw-bold"> - Аэропорт</span></p>
                                <div class="d-flex text-end flex-column">
                        <span><?php echo e($airline = $decoding['arrival_country']); ?> <span class="fw-bold"> - Страна</span></span>
                            <?php if($airline = $decoding['arrival_state'] != null): ?><span><?php echo e($airline = $decoding['arrival_state']); ?> <span class="fw-bold"> - Штат</span></span><?php endif; ?>
                                </div>
                            </div>
                        </div>
                        <hr>
                    <div class="d-flex justify-content-between">
                        <div>
                        <p><span class="fw-bold"> Класс бронирования:</span> <?php echo e($airline = $decoding['class_booking']); ?></p>
                        <p><span class="fw-bold"> Статус бронирования:</span> <?php echo e($airline = $decoding['booking_status']); ?></p>
                        <p><span class="fw-bold"> Зарезервированно мест:</span> <?php echo e($airline = $decoding['reserved_seats']); ?> мест</p>
                        </div>
                    <div>
                        <p><span class="fw-bold"> Самолёт:</span> <?php echo e($airline = $decoding['plane']); ?></p>
                        <p><span class="fw-bold"> Осталось мест:</span> <?php echo e($airline = $decoding['remaining_seats']); ?> мест</p>
                        <p><span class="fw-bold"> Номер рейса:</span> <?php echo e($airline = $decoding['flight_number']); ?></p>
                </div>
                </div>
                        <a href="#" class="btn btn-secondary read-less">Скрыть</a>
                    </div>
                </div>
                <div class="container">
                    <?php endif; ?>


        </div>
    </div>
</div>

    <script>
        $(document).ready(function() {
            // При нажатии на кнопку "Подробнее"
            $('.read-more').on('click', function(event) {
                event.preventDefault();
                // Скрываем краткий текст и показываем полный
                $(this).closest('.card').find('.card-text').addClass('d-none');
                $(this).closest('.card').find('.detail-text').removeClass('d-none');
            });

            // При нажатии на кнопку "Скрыть"
            $('.read-less').on('click', function(event) {
                event.preventDefault();
                // Скрываем полный текст и показываем краткий
                $(this).closest('.card').find('.card-text').removeClass('d-none');
                $(this).closest('.card').find('.detail-text').addClass('d-none');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\Hakaton\resources\views/home.blade.php ENDPATH**/ ?>