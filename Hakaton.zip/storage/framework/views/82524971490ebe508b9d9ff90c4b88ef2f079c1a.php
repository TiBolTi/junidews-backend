<?php $__env->startSection('content'); ?>

        <table  class="table table-bordered mt-5">
            <h2>Список Аэропортов</h2>
            <thead>
            <tr>
                <th style="text-align: center; width: 4%;" scope="col">#</th>
                <th scope="col">Название Аэропортов</th>
                <th scope="col">Коды Аэропортов</th>
                <th scope="col">Страна</th>

            </tr>
            </thead>
            <tbody style="vertical-align: middle;">
            <tr>
                <?php $__currentLoopData = $airports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airport): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="text-align: center"><?php echo e($airport->id); ?></td>
                    <td>
                        <?php echo e($airport->name); ?>

                    </td>

                    <td>
                        <?php echo e($airport->airport_iata); ?>

                    </td>
                    <td>
                        <?php echo e($airport->country->name); ?>

                    </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

<?php if(auth()->user()->can('add perms')): ?>
    <a href="<?php echo e(route('perms.create')); ?>" class="btn btn-success btn " tabindex="-1" role="button">Добавить разрешение</a>
<?php endif; ?>


    <?php $__env->startSection('delete'); ?>
        <script>
            var deleteModal = document.getElementById('deleteModal');
            deleteModal.addEventListener('show.bs.modal', function(event) {
                var button = event.relatedTarget;
                var table = button.getAttribute('data-table');
                var id = button.getAttribute('data-id');
                var form = deleteModal.querySelector('form');
                var actionUrl = "<?php echo e(url('/')); ?>/" + table + "/delete/" + id;
                form.setAttribute('action', actionUrl);
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\Hakaton\resources\views/airports/index.blade.php ENDPATH**/ ?>