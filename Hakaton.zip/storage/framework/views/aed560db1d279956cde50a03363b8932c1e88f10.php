<?php $__env->startSection('content'); ?>
    <?php echo e($decoding = null); ?>

<?php if($decoding != []): ?>
    <div class="card">
        <div class="card-body">
            <h5 class="card-title">Заголовок краткого текста</h5>
            <div class="d-flex flex-row justify-content-between align-items-center">
                <div>
                    <p>departure_airport: <?php echo e($airline = $decoding['departure_airport']); ?></p>
                    <p>departure_time: <?php echo e($airline = $decoding['departure_time']); ?></p>
                    <p>departure_date: <?php echo e($airline = $decoding['departure_date']); ?></p>
                </div>
                <div><p>Airline: <?php echo e($airline = $decoding['airline']); ?></p></div>
                <div>
                    <p>arrival_airport: <?php echo e($airline = $decoding['arrival_airport']); ?></p>
                    <p>arrival_time: <?php echo e($airline = $decoding['arrival_time']); ?></p>
                    <p>arrival_date: <?php echo e($airline = $decoding['arrival_date']); ?></p>

                </div>
            </div>
            <a href="#" class="btn btn-primary card-text read-more">Подробнее</a>
        </div>
        <div class="card-footer detail-text d-none">
            <p>Полный текст, который появится при нажатии на кнопку "Подробнее"</p>
            <a href="#" class="btn btn-secondary read-less">Скрыть</a>
        </div>
    </div>
    <div class="container">
        <p>Entered data: </p>
        <p>Airline: <?php echo e($airline = $decoding['airline']); ?></p>
        <p>flight_number: <?php echo e($airline = $decoding['flight_number']); ?></p>
        <p>class_booking: <?php echo e($airline = $decoding['class_booking']); ?></p>
        <p>departure_time: <?php echo e($airline = $decoding['departure_time']); ?></p>
        <p>arrival_time: <?php echo e($airline = $decoding['arrival_time']); ?></p>
        <p>departure_date: <?php echo e($airline = $decoding['departure_date']); ?></p>
        <p>arrival_date: <?php echo e($airline = $decoding['arrival_date']); ?></p>
        <p>week_day: <?php echo e($airline = $decoding['week_day']); ?></p>
        <p>departure_airport: <?php echo e($airline = $decoding['departure_airport']); ?></p>
        <p>arrival_airport: <?php echo e($airline = $decoding['arrival_airport']); ?></p>
        <p>departure_country: <?php echo e($airline = $decoding['departure_country']); ?></p>
        <p>arrival_country: <?php echo e($airline = $decoding['arrival_country']); ?></p>
        <p>departure_state: <?php echo e($airline = $decoding['departure_state']); ?></p>
        <p>arrival_state: <?php echo e($airline = $decoding['arrival_state']); ?></p>
        <p>plane: <?php echo e($airline = $decoding['plane']); ?></p>
        <p>booking_status: <?php echo e($airline = $decoding['booking_status']); ?></p>
        <p>reserved_seats: <?php echo e($airline = $decoding['reserved_seats']); ?></p>
        <p>remaining_seats: <?php echo e($airline = $decoding['remaining_seats']); ?></p>
        <?php endif; ?>
    <form action="<?php echo e(route('decode.decoder')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="exampleFormControlInput1">Заголовок</label>
            <input type="text" class="form-control" name="code" id="exampleFormControlInput1" placeholder="Введите заголовок ">
        </div>
        <button type="submit" class="btn btn-primary">Сохранить</button>
    </form>
</div>
    <script>
        $(document).ready(function() {
            // При нажатии на кнопку "Подробнее"
            $('.read-more').on('click', function(event) {
                event.preventDefault();
                // Скрываем краткий текст и показываем полный
                $(this).closest('.card').find('.card-text').addClass('d-none');
                $(this).closest('.card').find('.detail-text').removeClass('d-none');
            });

            // При нажатии на кнопку "Скрыть"
            $('.read-less').on('click', function(event) {
                event.preventDefault();
                // Скрываем полный текст и показываем краткий
                $(this).closest('.card').find('.card-text').removeClass('d-none');
                $(this).closest('.card').find('.detail-text').addClass('d-none');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\Hakaton\resources\views/decode/index.blade.php ENDPATH**/ ?>