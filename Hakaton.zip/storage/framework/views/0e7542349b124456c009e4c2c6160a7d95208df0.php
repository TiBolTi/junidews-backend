<?php $__env->startSection('content'); ?>

        <table  class="table table-bordered mt-5">
            <h2>Список разрешений</h2>
            <thead>
            <tr>
                <th style="text-align: center; width: 4%;" scope="col">#</th>
                <th  scope="col">Название разрешения</th>

            </tr>
            </thead>
            <tbody style="vertical-align: middle;">
            <tr>
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="text-align: center"><?php echo e($permission->id); ?></td>
                    <td class="d-flex align-items-center justify-content-between">

                        <span class="badge bg-primary me-1"><?php echo e($permission->name); ?></span>

                        <div class="dropdown dropstart">
                            <button class="btn btn-secondary" type="button" id="dropdownMenuButton1" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa-solid fa-ellipsis-vertical"></i>
                            </button>

                            <ul class="dropdown-menu" aria-labelledby="">
                                <li><a href="<?php echo e(route('perms.show', $permission)); ?>" class="btn dropdown-item" tabindex="-1"
                                       role="button">
                                        <i class="fa-solid fa-eye"></i> Просмотр</a></li>
                                <?php if(auth()->user()->can('edit perms')): ?>
                                <li>
                                    <a href="<?php echo e(route('perms.edit', $permission)); ?>" class="btn dropdown-item" id="<?php echo e($permission->id); ?>" tabindex="-1"
                                       role="button">
                                        <i class="fa-solid fa-pen"></i>  Изменить</a>
                                </li>
                                <?php endif; ?>
                                <?php if(auth()->user()->can('delete perms')): ?>
                                        <li>
                                    <button class="btn dropdown-item" data-bs-toggle="modal" data-bs-target="#deleteModal"
                                            data-table="perms" data-id="<?php echo e($permission->id); ?>">
                                        <i class="fa-solid fa-trash"></i> Удалить
                                    </button>
                                </li>
                                <?php endif; ?>
                            </ul>
                        </div>

                    </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

<?php if(auth()->user()->can('add perms')): ?>
    <a href="<?php echo e(route('perms.create')); ?>" class="btn btn-success btn " tabindex="-1" role="button">Добавить разрешение</a>
<?php endif; ?>


    <?php $__env->startSection('delete'); ?>
        <script>
            var deleteModal = document.getElementById('deleteModal');
            deleteModal.addEventListener('show.bs.modal', function(event) {
                var button = event.relatedTarget;
                var table = button.getAttribute('data-table');
                var id = button.getAttribute('data-id');
                var form = deleteModal.querySelector('form');
                var actionUrl = "<?php echo e(url('/')); ?>/" + table + "/delete/" + id;
                form.setAttribute('action', actionUrl);
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\Hakaton\resources\views/perms/index.blade.php ENDPATH**/ ?>