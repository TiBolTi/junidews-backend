<?php $__env->startSection('content'); ?>
    <h2>Обновить разрешение</h2>
    <form class="mb-5" action="<?php echo e(route('perms.update', $permission)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="form-group">
            <label for="name">Название</label>
            <input type="text" required name="name" value="<?php echo e($permission->name); ?>" class="form-control" placeholder="Введите название разрешения">
        </div>

        <button type="submit" class="btn mt-2 btn-primary">Обновить разрешение</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\Hakaton\resources\views/perms/edit.blade.php ENDPATH**/ ?>