<?php $__env->startSection('content'); ?>
    <h2>Просмотр разрешения</h2>

        <div class="form-group">
            <label for="name">Название</label>
            <input type="text" required name="name" value="<?php echo e($permission->name); ?>" class="form-control" placeholder="Введите название роли">
        </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\Hakaton\resources\views/perms/show.blade.php ENDPATH**/ ?>