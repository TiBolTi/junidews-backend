<?php $__env->startSection('content'); ?>

        <table  class="table table-bordered mt-5">
            <h2>Список авиялиний</h2>
            <thead>
            <tr>
                <th style="text-align: center; width: 4%;" scope="col">#</th>
                <th scope="col">Название Авиялиний</th>
                <th scope="col">Коды Авиялиний</th>

            </tr>
            </thead>
            <tbody style="vertical-align: middle;">
            <tr>
                <?php $__currentLoopData = $airlines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $airline): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td style="text-align: center"><?php echo e($airline->id); ?></td>
                    <td>
                        <?php echo e($airline->name); ?>

                    </td>

                    <td>
                        <?php echo e($airline->airline_iata); ?>

                    </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </tbody>
        </table>

<?php if(auth()->user()->can('add perms')): ?>
    <a href="<?php echo e(route('perms.create')); ?>" class="btn btn-success btn " tabindex="-1" role="button">Добавить разрешение</a>
<?php endif; ?>


    <?php $__env->startSection('delete'); ?>
        <script>
            var deleteModal = document.getElementById('deleteModal');
            deleteModal.addEventListener('show.bs.modal', function(event) {
                var button = event.relatedTarget;
                var table = button.getAttribute('data-table');
                var id = button.getAttribute('data-id');
                var form = deleteModal.querySelector('form');
                var actionUrl = "<?php echo e(url('/')); ?>/" + table + "/delete/" + id;
                form.setAttribute('action', actionUrl);
            });
        </script>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\user\Programs\OSPanel\domains\Hakaton\resources\views/airlines/index.blade.php ENDPATH**/ ?>